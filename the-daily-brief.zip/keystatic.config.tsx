import { config, collection, fields } from "@keystatic/core";
const repo = process.env.NEXT_PUBLIC_KEYSTATIC_GITHUB_REPO;
export default config({
  storage: repo ? { kind: "github", repo: repo as `${string}/${string}` } : { kind: "local" },
  collections: {
    articles: collection({
      label: "Articles",
      slugField: "title",
      path: "content/articles/*",
      format: { contentField: "content" },
      schema: {
        title: fields.slug({ name: { label: "Headline" } }),
        summary: fields.text({ label: "Summary", multiline: true }),
        category: fields.select({ label: "Category", options: [
          { label: "World", value: "World" }, { label: "Technology", value: "Technology" },
          { label: "Culture", value: "Culture" }, { label: "Environment", value: "Environment" }
        ], defaultValue: "World" }),
        date: fields.date({ label: "Publication date" }),
        author: fields.text({ label: "Author" }),
        content: fields.markdoc({ label: "Article body" })
      }
    })
  }
});
