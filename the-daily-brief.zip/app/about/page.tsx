import type { Metadata } from "next";
import Link from "next/link";
export const metadata: Metadata = { title: "About" };
export default function About() {
 return <div className="shell page-space about"><span className="eyebrow">WHO WE ARE</span><h1 className="page-title">A little more<br/>context<span className="accent">.</span></h1><p className="lead">The Daily Brief is a fictional online newspaper created to demonstrate a simple, accessible publishing experience.</p><div className="about-grid"><div><h2>Our approach</h2><p>We believe great digital reading should be calm, clear, and welcoming. This sample site puts articles first with a responsive layout and straightforward navigation.</p></div><div><h2>A note on accuracy</h2><p>All three launch articles, their authors, events, and quotations are invented for demonstration. They should not be mistaken for real reporting.</p></div></div><Link className="primary-link" href="/articles">Browse stories ↗</Link></div>;
}
