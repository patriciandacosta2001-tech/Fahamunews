import Link from "next/link";
export default function Footer() {
 return <footer className="footer"><div className="shell footer-inner"><span>© {new Date().getFullYear()} The Daily Brief · A fictional news demo</span><div><Link href="/about">About</Link><Link href="/keystatic">Editorial admin</Link></div></div></footer>;
}
