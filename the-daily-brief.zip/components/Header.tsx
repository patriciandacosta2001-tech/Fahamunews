import Link from "next/link";
export default function Header() {
  return <header className="site-header"><div className="shell nav">
    <Link href="/" className="brand">THE DAILY <span>BRIEF.</span></Link>
    <nav aria-label="Main navigation"><Link href="/">Home</Link><Link href="/articles">All stories</Link><Link href="/about">About</Link><Link href="/keystatic">Admin ↗</Link></nav>
  </div></header>;
}
