# The Daily Brief

A responsive fictional news demo built with Next.js App Router and Keystatic.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000 and manage articles at http://localhost:3000/keystatic.

## Deploy to Vercel

1. Push this project to GitHub and import the repository in Vercel.
2. Set `NEXT_PUBLIC_KEYSTATIC_GITHUB_REPO=owner/repo` in Vercel and locally to enable GitHub storage (replace with your repository).
3. Run locally with GitHub mode enabled, visit `/keystatic`, and follow the GitHub App setup.
4. Copy `KEYSTATIC_GITHUB_CLIENT_ID`, `KEYSTATIC_GITHUB_CLIENT_SECRET`, `KEYSTATIC_SECRET`, and `NEXT_PUBLIC_KEYSTATIC_GITHUB_APP_SLUG` into Vercel environment variables. Never commit these secrets.
5. Redeploy. Authorized GitHub collaborators with write access can edit via `/keystatic`. Changes committed to the repository trigger a new Vercel deployment.

Without `NEXT_PUBLIC_KEYSTATIC_GITHUB_REPO`, Keystatic uses local storage for development. Vercel's filesystem is not persistent: do not use local storage to edit production content.

All three articles are fictional examples, not real news. The site uses decorative CSS artwork rather than external images.
